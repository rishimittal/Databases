#include <iostream>
#include <string>
using namespace std;
class DBSystem {
	public:
	void readConfig(string configFilePath) {
	}

	void populatePageInfo() {
	}

	string getRecord(string tableName, int recordId) {
		return "record";
	}
};

