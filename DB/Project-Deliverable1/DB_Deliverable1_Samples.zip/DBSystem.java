public class DBSystem {
	public void readConfig(String configFilePath) {
	}

	public void populatePageInfo() {
	}

	public String getRecord(String tableName, int recordId) {
		return "record";
	}
}
