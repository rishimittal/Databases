
#javac Tester.java
java Tester > output
diff output outputfinal
