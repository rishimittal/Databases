import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.StringTokenizer;

/**
 * Created by neel on 2/3/14.
 */
public class ProcessSelect {


    public ProcessSelect(String projectList, String whereClause, String orderClause, String tableNames, DBSystem dbSystem) {
        String delim="";

        //set delimiter according to condition
        if(whereClause.contains(" and "))
            delim=" and ";
        else
            delim=" or ";
        String[] conditions=whereClause.toLowerCase().split(delim);
        /*for(int i=0;i<conditions.length;i++)
            System.out.println(conditions[i].trim());*/

        Integer[] columnNum=new Integer[conditions.length];
        String[] type=new String[conditions.length];
        String[] operator=new String[conditions.length];
        String[] compara=new String[conditions.length];

        //get table object for particular table name
        Iterator<Table> it=DBSystem.tableList.iterator();
        Table t=null;
        while (it.hasNext()){
            t=it.next();
            if(t.getName().equalsIgnoreCase(tableNames));
                break;
        }

        //get details related to column i.e. type and number
        HashMap<String,String> columnData=t.getColumnData();
        LinkedHashMap<String,Integer> colNum=t.getColumnNum();
        for(int i=0;i<conditions.length;i++){
            StringTokenizer stringTokenizer=new StringTokenizer(conditions[i],"=><!");
            //handling condtions with operators
            if(stringTokenizer.countTokens()>1){
                String column=stringTokenizer.nextToken();

                type[i]=columnData.get(column.trim());

                columnNum[i]=colNum.get(column.trim());
                //System.out.println(type[i]+" "+columnNum[i]);
                compara[i]=stringTokenizer.nextToken();
                operator[i]=conditions[i].substring(column.length(), conditions[i].length() - compara[i].length());

                //System.out.println(operator[i]);
            }else {
                //StringTokenizer stringTokenizer1=new StringTokenizer(conditions[i]);
                String[] column=conditions[i].split(" ");
                type[i]=columnData.get(column[0].trim());

                columnNum[i]=colNum.get(column[0].trim());
                operator[i]="like";
                compara[i]=column[2];
                //System.out.println(operator[i]);
            }
        }

        //logic to check and print
        int lines=t.getLines();
        String records="";

        //System.out.println(tableNames);

        delim=delim.trim();

        if(orderClause.equals("")){
            String[] tableColumn=projectList.split(",");
            Integer[] projectColumnNum=new Integer[tableColumn.length];
            for(int i=0;i<tableColumn.length;i++)
            {
                projectColumnNum[i]=colNum.get(tableColumn[i]);
                System.out.print("\""+tableColumn[i]+"\"");
                if(i!=tableColumn.length-1)
                    System.out.print(",");
            }
            System.out.println();

            for(int i=0;i<lines;i++)
            {
                records=dbSystem.getRecord(tableNames,i);
                if(checkCondition(conditions,columnNum,type,records,operator,compara,delim)){
                    String[] toPrint=records.split(",");
                    //System.out.println(toPrint[0]);
                    for (int j=0;j<tableColumn.length;j++){
                        System.out.print(toPrint[projectColumnNum[j]]);
                        if(j!=tableColumn.length-1)
                            System.out.print(",");
                    }
                    System.out.println();
                }
            }
            System.out.println();
        }


    }
    //check record for where conditions
    private boolean checkCondition(String[] conditions, Integer[] columnNum, String[] type, String records, String[] operator, String[] compara, String delim) {
        String[] splitstring=records.split(",");
        boolean retType=true;
        if(delim.equals("and"))
            retType=true;
        else
            retType=false;

        for(int i=0;i<conditions.length;i++)
        {
            if(operator[i].trim().equals("=")){
                if(type[i].equals("float")){
                    float lval=Float.parseFloat(splitstring[columnNum[i]].replace("\"",""));
                    float rval=Float.parseFloat(compara[i].trim());
                    if(lval==rval){
                        if(delim.equals("and"))
                            retType=retType&true;
                        else
                            retType=retType|true;
                    }
                    else{
                        if(delim.equals("and"))
                            retType=retType&false;
                        else
                            retType=retType|false;
                    }
                }else if(type[i].equals("int")){
                    int lval=Integer.parseInt(splitstring[columnNum[i]].replace("\"", ""));
                    int rval=Integer.parseInt(compara[i].trim());
                    if(lval==rval){
                        if(delim.equals("and"))
                            retType=retType&true;
                        else
                            retType=retType|true;
                    }
                    else{
                        if(delim.equals("and"))
                            retType=retType&false;
                        else
                            retType=retType|false;
                    }
                }else if(type[i].equals("string")){
                    String lval=splitstring[columnNum[i]].replace("\"","");
                    String rval=compara[i].trim().replace("'", "");
                    if(lval.equals(rval)){
                        if(delim.equals("and"))
                            retType=retType&true;
                        else
                            retType=retType|true;
                    }
                    else{
                        if(delim.equals("and"))
                            retType=retType&false;
                        else
                            retType=retType|false;
                    }
                }


            }else if(operator[i].trim().equals(">=")){
                if(type[i].equals("float")){
                    float lval=Float.parseFloat(splitstring[columnNum[i]].replace("\"",""));
                    float rval=Float.parseFloat(compara[i].trim());
                    if(lval>=rval){
                        if(delim.equals("and"))
                            retType=retType&true;
                        else
                            retType=retType|true;
                    }
                    else{
                        if(delim.equals("and"))
                            retType=retType&false;
                        else
                            retType=retType|false;
                    }
                }else if(type[i].equals("int")){
                    int lval=Integer.parseInt(splitstring[columnNum[i]].replace("\"", ""));
                    int rval=Integer.parseInt(compara[i].trim());
                    if(lval>=rval){
                        if(delim.equals("and"))
                            retType=retType&true;
                        else
                            retType=retType|true;
                    }
                    else{
                        if(delim.equals("and"))
                            retType=retType&false;
                        else
                            retType=retType|false;
                    }
                }

            }else if(operator[i].trim().equals("<=")){
                if(type[i].equals("float")){
                    float lval=Float.parseFloat(splitstring[columnNum[i]].replace("\"",""));
                    float rval=Float.parseFloat(compara[i].trim());
                    if(lval<=rval){
                        if(delim.equals("and"))
                            retType=retType&true;
                        else
                            retType=retType|true;
                    }
                    else{
                        if(delim.equals("and"))
                            retType=retType&false;
                        else
                            retType=retType|false;
                    }
                }else if(type[i].equals("int")){
                    int lval=Integer.parseInt(splitstring[columnNum[i]].replace("\"", ""));
                    int rval=Integer.parseInt(compara[i].trim());
                    if(lval<=rval){
                        if(delim.equals("and"))
                            retType=retType&true;
                        else
                            retType=retType|true;
                    }
                    else{
                        if(delim.equals("and"))
                            retType=retType&false;
                        else
                            retType=retType|false;
                    }
                }

            }else if(operator[i].trim().equals("!=")){
                if(type[i].equals("float")){
                    float lval=Float.parseFloat(splitstring[columnNum[i]].replace("\"",""));
                    float rval=Float.parseFloat(compara[i].trim());
                    if(lval!=rval){
                        if(delim.equals("and"))
                            retType=retType&true;
                        else
                            retType=retType|true;
                    }
                    else{
                        if(delim.equals("and"))
                            retType=retType&false;
                        else
                            retType=retType|false;
                    }
                }else if(type[i].equals("int")){
                    int lval=Integer.parseInt(splitstring[columnNum[i]].replace("\"", ""));
                    int rval=Integer.parseInt(compara[i].trim());
                    if(lval!=rval){
                        if(delim.equals("and"))
                            retType=retType&true;
                        else
                            retType=retType|true;
                    }
                    else{
                        if(delim.equals("and"))
                            retType=retType&false;
                        else
                            retType=retType|false;
                    }
                }

            }else if(operator[i].trim().equals(">")){
                if(type[i].equals("float")){
                    float lval=Float.parseFloat(splitstring[columnNum[i]].replace("\"",""));
                    float rval=Float.parseFloat(compara[i].trim());
                    if(lval>rval){
                        if(delim.equals("and"))
                            retType=retType&true;
                        else
                            retType=retType|true;
                    }
                    else{
                        if(delim.equals("and"))
                            retType=retType&false;
                        else
                            retType=retType|false;
                    }
                }else if(type[i].equals("int")){
                    int lval=Integer.parseInt(splitstring[columnNum[i]].replace("\"", ""));
                    int rval=Integer.parseInt(compara[i].trim());
                    if(lval>rval){
                        if(delim.equals("and"))
                            retType=retType&true;
                        else
                            retType=retType|true;
                    }
                    else{
                        if(delim.equals("and"))
                            retType=retType&false;
                        else
                            retType=retType|false;
                    }
                }

            }else if(operator[i].trim().equals("<")){
                if(type[i].equals("float")){
                    float lval=Float.parseFloat(splitstring[columnNum[i]].replace("\"",""));
                    float rval=Float.parseFloat(compara[i].trim());
                    if(lval<rval){
                        if(delim.equals("and"))
                            retType=retType&true;
                        else
                            retType=retType|true;
                    }
                    else{
                        if(delim.equals("and"))
                            retType=retType&false;
                        else
                            retType=retType|false;
                    }
                }else if(type[i].equals("int")){
                    int lval=Integer.parseInt(splitstring[columnNum[i]].replace("\"", ""));
                    int rval=Integer.parseInt(compara[i].trim());
                    if(lval<rval){
                        if(delim.equals("and"))
                            retType=retType&true;
                        else
                            retType=retType|true;
                    }
                    else{
                        if(delim.equals("and"))
                            retType=retType&false;
                        else
                            retType=retType|false;
                    }
                }

            }else if(operator[i].trim().equals("like")){

                if(type[i].equals("string")){
                    String lval=splitstring[columnNum[i]].replace("\"","");
                    String rval=compara[i].trim().replace("'","");
                    if(lval.equalsIgnoreCase(rval)){
                        if(delim.equals("and"))
                            retType=retType&true;
                        else
                            retType=retType|true;
                    }
                    else{
                        if(delim.equals("and"))
                            retType=retType&false;
                        else
                            retType=retType|false;
                    }
                }
            }
        }
        return retType;
    }
}
